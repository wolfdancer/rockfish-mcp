import unittest

import pyarrow as pa
import rockfish as rf

from data_quality_report.split_label import get_split_label


class TestReport(unittest.TestCase):
    def test_name_conflict(self):
        table = pa.table({"a": [1, 2, 3], "split_label": [4, 5, 6]})
        ori = rf.Dataset.from_table("ori", table)
        syn = rf.Dataset.from_table("syn", table)
        self.assertFalse(get_split_label([ori, syn]) in ori.table.column_names)
