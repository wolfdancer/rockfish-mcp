from typing import Any
from typing import Literal

import matplotlib.pyplot as plt
import pandas as pd
import rockfish as rf
import rockfish.actions as ra
import seaborn as sns
from rockfish.actions.txtr import EvaluateLogisticRegression
from rockfish.actions.txtr import EvaluateRandomForest
from rockfish.dataset import LocalDataset

from data_quality_report.split_label import get_split_label

TXTR_MODEL = {"lr": EvaluateLogisticRegression, "rf": EvaluateRandomForest}
_FULL_MODEL_NAME = {"lr": "Logistic Regression", "rf": "Random Forest"}


async def eval_model(
    train_ds: LocalDataset,
    test_ds: LocalDataset,
    conn: rf.AbstractConnection,
    config: dict[str, Any],
    *,
    model: Literal["lr", "rf"] = "lr",
    worker_group: str | None = None,
):
    split_label = get_split_label([train_ds, test_ds])
    config["table_split_col_name"] = split_label
    query = f"""
    select *,'train' as {split_label} from train
    union all
    select *,'test' as {split_label} from control
    """
    evaluate = TXTR_MODEL[model](config)
    save = ra.DatasetSave(name="txtr")
    test_ds_remote = await test_ds.to_remote(conn)
    concat = ra.SQL(
        query=query,
        table_name="train",
        dataset_name_to_id={"control": test_ds_remote.id},
    )
    builder = rf.WorkflowBuilder()
    builder.worker_group(worker_group)
    builder.add_path(train_ds, concat, evaluate, save)
    workflow = await builder.start(conn)
    await workflow.wait(raise_on_failure=True)
    res = await workflow.datasets().concat(conn)
    return res.table.column("auc").to_pylist()[0]


async def utility_evaluate(
    ori: LocalDataset,
    syn: LocalDataset,
    control: LocalDataset,
    conn: rf.AbstractConnection,
    *,
    worker_group: str | None = None,
    utility_config: dict[str, Any] | None = None,
    rank: bool = True,
) -> pd.DataFrame | None:
    """
    Evaluate the utility of the synthetic data.

    :param ori:
        The original dataset.
    :param syn:
        The synthetic dataset.
    :param control:
        The control/test dataset.
    :param conn:
        The connection to the Rockfish API.
    :param worker_group:
        The worker group to use for Rockfish actions.
    :param utility_config:
        The utility configuration.  The table_split_col_name in the
        configuration will be overriden by an automatically generated unique
        name.
    :param rank:
        Whether to rank the models.

    :return:
        The utility results.
    """
    if utility_config is None:
        return None
    auc = {"lr": [], "rf": []}
    model_list = ["lr", "rf"]
    for model in model_list:
        for ds in [ori, syn]:
            auc[model].append(
                await eval_model(
                    ds,
                    control,
                    conn,
                    utility_config,
                    model=model,
                    worker_group=worker_group,
                )
            )
    df = pd.DataFrame(
        auc,
        index=["Original", "Synthetic"],
    )
    df.columns = [_FULL_MODEL_NAME[model] for model in model_list]
    if rank:
        columns = [col for _, col in sorted(zip(df.iloc[0], df.columns), reverse=True)]
        df = df[columns]
    return df


def plot_bar(df: pd.DataFrame) -> plt.Figure:
    fig, (ax1, ax2) = plt.subplots(1, 2, sharey=True)
    colors = sns.color_palette()[2 : 2 + len(df.columns)]
    sns.barplot(data=df.iloc[0:1], ax=ax1, palette=colors)
    ax1.set_title(df.index[0])
    for i in range(len(ax1.containers)):
        ax1.bar_label(ax1.containers[i])
    sns.barplot(data=df.iloc[1:2], ax=ax2, palette=colors)
    ax2.set_title(df.index[1])
    for i in range(len(ax2.containers)):
        ax2.bar_label(ax2.containers[i])
    ax1.set_ylim(0, 1.08)
    ax1.set_ylabel("AUC")
    plt.tight_layout()
    return fig


def rank_correlation(df: pd.DataFrame) -> float:
    return df.T.corr(method="spearman").iloc[0, 1]
