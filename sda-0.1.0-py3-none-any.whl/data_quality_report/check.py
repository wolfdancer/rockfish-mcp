import base64
import copy
import io
import os
from pathlib import Path
from typing import Any
from typing import Literal
from typing import Optional

import attrs
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import rockfish as rf
import rockfish.actions as ra
import rockfish.labs as rl
from jinja2 import Environment
from jinja2 import PackageLoader
from jinja2 import select_autoescape
from rockfish import arrow
from rockfish.actions import privacy
from rockfish.dataset import LocalDataset

from data_quality_report.model_ranking import plot_bar
from data_quality_report.model_ranking import rank_correlation
from data_quality_report.model_ranking import utility_evaluate
from data_quality_report.split_label import get_split_label


def _extract_from_config(config: Any):
    """Extract data information from the train config file. Currently it does
    not consider ignored fields in evaluation."""
    # TODO: Later on, evaluation config probably can be retrieved from model store or TableMetadata
    data_info_dict = {}
    config = rf.converter.unstructure(config)
    encoder_config = config["encoder"]

    if len(set(list(encoder_config.keys()))) > 1:
        if "doppelganger" in config.keys():
            data_info_dict["model_name"] = "RF-Time-GAN"
        elif "rtf" in config.keys():
            data_info_dict["model_name"] = "RF-Time-Transformer"
        else:
            data_info_dict["model_name"] = "Unknown Model"
        # timeseries data has metadata, cat_fields, num_fields, timestamp, session_key_field(optional)
        data_info_dict["cat_fields"] = []
        data_info_dict["num_fields"] = []
        data_info_dict["metadata"] = []
        data_info_dict["measurements"] = []
        data_info_dict["ignored_fields"] = []
        # timeseries data:
        for item in encoder_config.get("metadata"):
            if item.get("type") != "ignore":
                if item.get("type") == "session":
                    # currently only RF-Time-GAN config has type session.
                    # Later, we can update the check if type session works for other models
                    if data_info_dict["model_name"] == "RF-Time-GAN":
                        data_info_dict["session_key_field"] = item.get("field")
                    else:
                        raise ValueError(
                            f"Model{data_info_dict['model_name']!r} does not support the type: 'session' in configuration"
                        )
                elif item.get("type") == "categorical":
                    data_info_dict["cat_fields"].append(item.get("field"))
                    data_info_dict["metadata"].append(item.get("field"))
                else:
                    data_info_dict["num_fields"].append(item.get("field"))
                    data_info_dict["metadata"].append(item.get("field"))
            else:
                data_info_dict["ignored_fields"].append(item.get("field"))

        # for backward compatibility - "timeseries" and "features" are
        # deprecated (need to think about whether to consider deprecated
        # parameters when productizing)
        # DG supports: https://github.com/Rockfish-Data/rockfish-sdk/blob/3dcae3ccb423715227c55cdc24040e8de53805ef/src/rockfish/actions/dg.py#L162-L171
        # rtf supports: https://github.com/Rockfish-Data/cuttlefish/blob/9544ed200a1a77b6026b910ca5cf016cb863ebb0/lib/rtf/src/actions/rtf.py#L210-L214
        for item in (
            encoder_config.get("measurements", [])
            + encoder_config.get("timeseries", [])
            + encoder_config.get("features", [])
        ):
            if item.get("type") != "ignore":
                if item.get("type") == "categorical":
                    data_info_dict["cat_fields"].append(item.get("field"))
                else:
                    data_info_dict["num_fields"].append(item.get("field"))
                data_info_dict["measurements"].append(item.get("field"))
            else:
                data_info_dict["ignored_fields"].append(item.get("field"))
        ts_field = encoder_config.get("timestamp", {}).get("field", "")
        data_info_dict["timestamp"] = ts_field

    else:
        # tabular dataset
        if "tabular-gan" in config.keys():
            data_info_dict["model_name"] = "RF-Tab-GAN"
        elif "rtf" in config.keys():
            data_info_dict["model_name"] = "RF-Tab-Transformer"
        else:
            data_info_dict["model_name"] = "Unknown Model"
        # for backward compatibility - "measurements" are deprecated (need to think about whether to consider deprecated
        # parameters when productizing)
        # ctgan supports: https://github.com/Rockfish-Data/cuttlefish/blob/9544ed200a1a77b6026b910ca5cf016cb863ebb0/lib/ctg/src/actions/tabulargan.py#L89-L92
        fields = encoder_config.get("metadata", []) + encoder_config.get(
            "measurements", []
        )
        data_info_dict["cat_fields"] = [
            item.get("field") for item in fields if item.get("type") == "categorical"
        ]

        data_info_dict["num_fields"] = [
            item.get("field")
            for item in fields
            if item.get("type") == "continuous" or not item.get("type")
        ]
        data_info_dict["metadata"] = (
            data_info_dict["cat_fields"] + data_info_dict["num_fields"]
        )
        data_info_dict["ignored_fields"] = [
            item.get("field") for item in fields if item.get("type") == "ignore"
        ]
    return data_info_dict


class Assessor:
    dataset: LocalDataset
    syn: LocalDataset
    control: Optional[LocalDataset] = None
    # TODO: currently it feeds the train config and later on, once this info
    # stored in somewhere(train action/model store/ TableMetadata), then this
    # attribute will be an optional input
    config: Any

    def __init__(
        self,
        dataset: LocalDataset,
        syn: LocalDataset,
        *,
        control: Optional[LocalDataset] = None,
        config: Any = None,
    ):
        self.dataset = dataset
        self.syn = syn
        self.control = control
        if config:
            self.eval_config = _extract_from_config(config)
        else:
            # TODO: self.eval_config from model staore or TableMetadata() once
            # all train config info stored in those places
            self.eval_config = {}
        self.session_key_field = self.eval_config.get("session_key_field")
        self.utility_results = None

    def _compute_sessions(self):
        if self.session_key_field:
            source_sessions = arrow.group_table(
                self.dataset.table, group_fields=[self.session_key_field]
            ).num_rows
        else:
            source_sessions = arrow.group_table(
                self.dataset.table, group_fields=self.eval_config.get("metadata")
            ).num_rows

        if "session_key" in self.syn.table.column_names:
            syn_sessions = arrow.group_table(
                self.syn.table, group_fields=["session_key"]
            ).num_rows
        elif (
            self.session_key_field
            and self.session_key_field in self.syn.table.column_names
        ):
            # TODO: Info message, session_key has been renamed to session_key_field
            syn_sessions = arrow.group_table(
                self.syn.table, group_fields=[self.session_key_field]
            ).num_rows
        elif self.session_key_field is None:
            syn_sessions = "'session_key' is not present in the synthetic data. Hence, cannot compute the number of sessions as well as any session related metrics"
        else:
            syn_sessions = f"{self.session_key_field!r} and 'session_key' are not present in the synthetic data. Hence, cannot compute the number of sessions as well as any session related metric"
        return source_sessions, syn_sessions

    def _rearrange_columns(
        self,
    ) -> tuple[LocalDataset, LocalDataset, Optional[LocalDataset]]:
        """Rearrange the synthetic data to match the real data for evaluation.

        Since the generated synthetic data may have different order of
        columns, or different columns ("session_key" in synthetic timeseries
        datset), _rearrange_columns is created here temporarily to convert the
        synthetic data as the same as the real in order for evaluation.

        Eventually, it should be removed and all the converted should have
        been done when generating the synthetic data.
        """
        # since helper function will alter the dataset, we need to make a deepcopy
        dataset = copy.deepcopy(self.dataset)
        syn = copy.deepcopy(self.syn)
        control = copy.deepcopy(self.control)
        # timeseries dataset
        if "timestamp" in self.eval_config:
            if isinstance(self._compute_sessions()[1], str):
                # if number of sessions cannot be computed then it cannot evaluate session-related metrics and we treat them as tabular data
                dataset.table = dataset.table.select(
                    self.eval_config["cat_fields"] + self.eval_config["num_fields"]
                )
                syn.table = syn.table.select(
                    self.eval_config["cat_fields"] + self.eval_config["num_fields"]
                )
                if control is not None:
                    control.table = control.table.select(
                        self.eval_config["cat_fields"] + self.eval_config["num_fields"]
                    )
            else:
                # session related metrics can be evaluated
                if self.session_key_field:
                    syn_column_names = syn.table.column_names
                    if "session_key" in syn.table.column_names:
                        # replace "session_key" with the session_key_field
                        syn_column_names[syn_column_names.index("session_key")] = (
                            self.session_key_field
                        )
                        syn.table = syn.table.rename_columns(syn_column_names)

                    # select the specified fields for evaluation
                    dataset.table = dataset.table.select(
                        [self.session_key_field]
                        + self.eval_config["cat_fields"]
                        + self.eval_config["num_fields"]
                        + [self.eval_config["timestamp"]]
                    )
                    syn.table = syn.table.select(
                        [self.session_key_field]
                        + self.eval_config["cat_fields"]
                        + self.eval_config["num_fields"]
                        + [self.eval_config["timestamp"]]
                    )
                    if control is not None:
                        control.table = control.table.select(
                            [self.session_key_field]
                            + self.eval_config["cat_fields"]
                            + self.eval_config["num_fields"]
                            + [self.eval_config["timestamp"]]
                        )
                    schema_metadata = rf.arrow.SchemaMetadata(
                        metadata=[self.session_key_field]
                    )
                else:
                    # keep "session_key" in synthetic, then add "session_key" in real
                    df = dataset.to_pandas()
                    df["session_key"] = df.groupby(
                        self.eval_config["metadata"]
                    ).ngroup()
                    dataset = LocalDataset.from_pandas(dataset.name(), df)
                    dataset.table = dataset.table.select(
                        ["session_key"]
                        + self.eval_config["cat_fields"]
                        + self.eval_config["num_fields"]
                        + [self.eval_config["timestamp"]]
                    )
                    syn.table = syn.table.select(
                        ["session_key"]
                        + self.eval_config["cat_fields"]
                        + self.eval_config["num_fields"]
                        + [self.eval_config["timestamp"]]
                    )
                    if control is not None:
                        control.table = control.table.select(
                            ["session_key"]
                            + self.eval_config["cat_fields"]
                            + self.eval_config["num_fields"]
                            + [self.eval_config["timestamp"]]
                        )
                    schema_metadata = rf.arrow.SchemaMetadata(metadata=["session_key"])

                dataset.table = rf.arrow.replace_schema_metadata(
                    dataset.table, schema_metadata
                )
                syn.table = rf.arrow.replace_schema_metadata(syn.table, schema_metadata)
                if control is not None:
                    control.table = rf.arrow.replace_schema_metadata(
                        control.table, schema_metadata
                    )

        # In order to cast schema, we need to have the same column orders
        syn.table = syn.table.select(dataset.table.column_names)
        syn.table = syn.table.cast(dataset.table.schema, safe=False)
        if control is not None:
            control.table = control.table.select(dataset.table.column_names)
            control.table = control.table.cast(dataset.table.schema, safe=False)
        return dataset, syn, control

    def check_shapes(self):
        # TODO: could improve the way to define whether it is timeseries or not
        if self.eval_config.get("timestamp"):
            # timeseries dataset
            if (
                "session_key" in self.syn.table.column_names
                and not self.eval_config.get("session_key_field")
            ):
                message = "Synthetic data has one additional field 'session_key'."
            else:
                message = ""

            shape_dict = {
                "Comparison": ["Number of Fields", "Number of Sessions"],
                # sessions is computed on the assumption that "session_key" field is present in
                # synthetic data
                "Source": [self.dataset.table.num_columns, self._compute_sessions()[0]],
                "Synthetic": [self.syn.table.num_columns, self._compute_sessions()[1]],
                "Note": [
                    message,
                    "If users do not specify the number of sessions to generate, the default should match the source data. Otherwise, it should match the value specified by the user.",
                ],
            }
        else:
            # tabular dataset
            shape_dict = {
                "Comparison": ["Number of Fields", "Number of Rows"],
                "Source": [self.dataset.table.num_columns, self.dataset.table.num_rows],
                "Synthetic": [self.dataset.table.num_columns, self.syn.table.num_rows],
                "Note": [
                    "",
                    "If users do not specify the number of sessions to generate, the default should match the source data. Otherwise, it should match the value specified by the user.",
                ],
            }

        return shape_dict  # output displayed in the report

    def check_field_names(self):
        self.matched_fields = set(self.dataset.table.column_names) & set(
            self.syn.table.column_names
        )
        field_names_dict = {
            "Fields in source but not in synthetic": set(
                self.dataset.table.column_names
            )
            - set(self.syn.table.column_names),
            "Fields in synthetic but not in source": set(self.syn.table.column_names)
            - set(self.dataset.table.column_names),
        }
        self.field_names_dict = field_names_dict
        return f"{len(self.matched_fields)} field names match"

    def check_field_types(self, select_fields=None):
        """If select_fields is None, it will check all matched fields"""
        if select_fields is None:
            select_fields = self.matched_fields
        count = 0
        field_types_dict = {
            "Type Mismatched Fields": [],
            "Source": [],
            "Synthetic": [],
        }
        for field in select_fields:
            match = self.dataset.table[field].type == self.syn.table[field].type

            if match:
                count += 1
            else:
                field_types_dict["Type Mismatched Fields"].append(f"{field!r}")
                field_types_dict["Source"].append(self.dataset.table[field].type)
                field_types_dict["Synthetic"].append(self.syn.table[field].type)
        self.field_types_dict = field_types_dict
        return f"{count} fields have matching field types"

    def check_field_positions(self, select_fields=None):
        """If select_fields is None, it will check all matched fields"""
        if select_fields is None:
            select_fields = self.matched_fields
        count = 0
        field_positions_dict = {
            "Position Mismatched Fields": [],
        }
        for field in select_fields:
            match = self.dataset.table.schema.get_field_index(
                field
            ) == self.syn.table.schema.get_field_index(field)
            if match:
                count += 1
            else:
                field_positions_dict["Position Mismatched Fields"].append(field)
        self.field_positions_dict = field_positions_dict
        return f"{count} fields have matching positions"

    async def report(
        self,
        *,
        output_file: str = "output.html",
        return_results: bool = False,
        kwargs_eval: Optional[dict] = None,
        kwargs_generate: Optional[dict] = None,
        conn: Optional[rf.AbstractConnection] = None,
        worker_group: Optional[str] = None,
        link_config: Optional[privacy.LinkabilityConfig] = None,
        inf_config: Optional[privacy.InferenceConfig] = None,
        utility_config: Optional[dict[str, Any]] = None,
    ):
        if kwargs_eval is None:
            kwargs_eval = {}
        if kwargs_generate is None:
            kwargs_generate = {}

        ori, syn, control = self._rearrange_columns()
        self.fidelity_results_dict = fidelity_evaluate(
            [ori, syn], self.eval_config, **kwargs_eval
        )
        self.privacy_results = await privacy_evaluate(
            ori,
            syn,
            self.eval_config,
            conn=conn,
            worker_group=worker_group,
            control=control,
            link_config=link_config,
            inf_config=inf_config,
        )
        self.utility_results = await utility_evaluate(
            ori,
            syn,
            control,
            conn,
            worker_group=worker_group,
            utility_config=utility_config,
        )
        output_html = self._render_template(self._generate_data(**kwargs_generate))
        # Support full paths in output_file parameter
        output_path = Path(output_file)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        with open(output_path, "w") as f:
            f.write(output_html)
        if return_results:
            # returned output can be updated to store as a file if needed
            return self.fidelity_results_dict

    def _generate_data(self, decimal_places: int = 4):
        data = {
            "title": "Data Quality Report",
            "model_name": self.eval_config.get("model_name", ""),
            "data_shape_comparison": self.check_shapes(),
            "field_name_check": self.check_field_names(),
            "mismatched_field_names": self.field_names_dict,
            "field_type_check": self.check_field_types(),
            "mismatched_field_types": self.field_types_dict,
            "field_position_check": self.check_field_positions(),
            "mismatched_field_positions": self.field_positions_dict,
            "ignored_fields": self.eval_config.get("ignored_fields"),
            "overall_marginal_score": _round_float(
                self.fidelity_results_dict.get("overall_marginal_score"),
                decimal_places,
            ),
            "marginal_hyperlink": "https://docs.rockfish.ai/data-eval.html#overall-fidelity-score",
            "session_length": self.fidelity_results_dict.get("session_length", None),
            "interarrival": self.fidelity_results_dict.get("interarrival", None),
            "range_adherence_score": _round_float(
                self.fidelity_results_dict.get("range_adherence_score"),
                decimal_places,
            ),
            "num_figures": self.fidelity_results_dict.get("num_figures", None),
            "cat_figures": self.fidelity_results_dict.get("cat_figures", None),
            "corr_score": _round_float(
                self.fidelity_results_dict.get("corr_score"), decimal_places
            ),
            "corr_hyperlink": "https://docs.rockfish.ai/sdk/labs-metrics.html#rockfish.labs.metrics.correlation_score",
            "corr_figures": self.fidelity_results_dict.get("corr_figures", None),
            "asso_score": _round_float(
                self.fidelity_results_dict.get("asso_score"), decimal_places
            ),
            "asso_hyperlink": "https://docs.rockfish.ai/sdk/labs-metrics.html#rockfish.labs.metrics.association_score",
            "asso_figures": self.fidelity_results_dict.get("asso_figures", None),
            "memorization_rate": _round_float(
                self.privacy_results.memorization_rate, decimal_places
            ),
            "DCR": _round_float(self.privacy_results.dcr, decimal_places),
            "linkability": _round_float(
                self.privacy_results.linkability, decimal_places
            ),
            "inference": _round_float(self.privacy_results.inference, decimal_places),
            "average_privacy_score": _round_float(
                self.privacy_results.average_privacy_score(),
                decimal_places,
            ),
            "memorization_hyperlink": "https://docs.rockfish.ai/sdk/labs-metrics.html#rockfish.labs.metrics.memorization_rate",
            "dcr_hyperlink": "https://docs.rockfish.ai/sdk/labs-metrics.html#rockfish.labs.metrics.distance_to_closest_record_score",
        }
        if self.utility_results is not None:
            data["utility_figure"] = _fig_to_base64(
                plot_bar(_round_float(self.utility_results, decimal_places))
            )
            plt.close()
            data["rank_correlation"] = rank_correlation(self.utility_results)
        return data

    def _render_template(self, data: dict[str, Any]) -> str:
        env = Environment(
            loader=PackageLoader("data_quality_report", "html_templates"),
            autoescape=select_autoescape(),
        )
        template = env.get_template("template.html")
        return template.render(data)


def _round_float(
    value: float | np.ndarray | list[float] | pd.DataFrame | None, decimal_places: int
) -> float | np.ndarray | list[float] | pd.DataFrame:
    if value is None:
        return np.nan
    if isinstance(value, float):
        if np.isnan(value):
            return np.nan
        return round(value, decimal_places)
    if isinstance(value, np.ndarray):
        return np.round(value, decimal_places)
    if isinstance(value, list):
        return np.round(value, decimal_places).tolist()
    if isinstance(value, pd.DataFrame):
        return value.round(decimal_places)
    raise ValueError(f"Unsupported type: {type(value)}")


def _fig_to_base64(fig):
    """Convert a figure(plot) to a base64 string"""
    buf = io.BytesIO()
    fig.savefig(buf, format="png")
    img_str = base64.b64encode(buf.getbuffer()).decode("utf-8")
    buf.close()
    return img_str


def fidelity_evaluate(
    datasets: list[LocalDataset],
    data_info_dict: dict,
    corr_fields: Optional[list] = None,
    asso_fields: Optional[list] = None,
    cont_plot_type: Literal["kde", "hist"] = "kde",
    **plot_kwargs,
):
    """Evaluate the source data and synthetic data and return the results in a dictionary

    :param datasets:
        List of real and synthetic datasets (real first, synthetic second).
    """
    if corr_fields is None:
        corr_fields = []
    if asso_fields is None:
        asso_fields = []
    if cont_plot_type == "kde":
        plotting_func = rl.vis.plot_kde
    else:
        plotting_func = rl.vis.plot_hist
    fidelity_results_dict = dict()
    # if timeseries data with session_key_field specified or "session_key" in the datasets
    if (
        data_info_dict.get("session_key_field")
        or "session_key" in datasets[1].table.column_names
    ):
        # session_length
        source_sess = rf.metrics.session_length(datasets[0])
        syn_sess = rf.metrics.session_length(datasets[1])
        fidelity_results_dict["session_length"] = _fig_to_base64(
            plotting_func([source_sess, syn_sess], "session_length", **plot_kwargs)
        )
        plt.close()
        # interarrival
        source_interarrival = rf.metrics.interarrivals(
            datasets[0], data_info_dict["timestamp"]
        )
        syn_interarrival = rf.metrics.interarrivals(
            datasets[1], data_info_dict["timestamp"]
        )
        fidelity_results_dict["interarrival"] = _fig_to_base64(
            plotting_func(
                [source_interarrival, syn_interarrival],
                "interarrival",
                duration_unit="s",  # currently, the default is unit s, later can be updated based on the config
                **plot_kwargs,
            )
        )
        plt.close()
        # marginal score considering session_length and interarrival
        overall_marginal_score = rl.metrics.marginal_dist_score(
            dataset=datasets[0],
            syn=datasets[1],
            metadata=[data_info_dict.get("session_key_field") or "session_key"],
            other_categorical=data_info_dict["cat_fields"],
            weights={
                data_info_dict.get("session_key_field") or "session_key": 0,
            },
        )
        fidelity_results_dict["overall_marginal_score"] = overall_marginal_score
    else:
        # marginal score without considering session_length and interarrival, same as computing marginal score for tabular data
        overall_marginal_score = rl.metrics.marginal_dist_score(
            dataset=datasets[0],
            syn=datasets[1],
            other_categorical=data_info_dict["cat_fields"],
        )
        fidelity_results_dict["overall_marginal_score"] = overall_marginal_score

    # get the range adherence score if there are numercial fields
    if data_info_dict.get("num_fields"):
        range_adherence_score = rl.metrics.range_adherence_score(
            datasets[0], datasets[1], data_info_dict["num_fields"]
        )
        fidelity_results_dict["range_adherence_score"] = range_adherence_score

    fidelity_results_dict["num_figures"] = []
    for field in data_info_dict.get("num_fields", []):
        fidelity_results_dict["num_figures"].append(
            _fig_to_base64(plotting_func(datasets, field, **plot_kwargs))
        )
        plt.close()

    fidelity_results_dict["cat_figures"] = []
    for field in data_info_dict.get("cat_fields", []):
        fidelity_results_dict["cat_figures"].append(
            _fig_to_base64(rl.vis.plot_bar(datasets, field))
        )
        plt.close()

    fidelity_results_dict["corr_figures"] = []
    if not corr_fields:
        corr_fields = data_info_dict["num_fields"]
    if len(corr_fields) > 1:
        fidelity_results_dict["corr_figures"].append(
            _fig_to_base64(
                rl.vis.plot_correlation_heatmap(
                    datasets=datasets,
                    fields=corr_fields,
                )
            )
        )
        plt.close()

        # correlation score
        corr_score = rl.metrics.correlation_score(*datasets, corr_fields)
        fidelity_results_dict["corr_score"] = corr_score

    fidelity_results_dict["asso_figures"] = []
    if not asso_fields:
        asso_fields = data_info_dict["cat_fields"]
        asso_fields = [
            f
            for f in asso_fields
            if len(datasets[0].table[f].unique()) > 1
            and len(datasets[1].table[f].unique()) > 1
        ]
    if len(asso_fields) > 1:
        fidelity_results_dict["asso_figures"].append(
            _fig_to_base64(
                rl.vis.plot_association_heatmap(
                    datasets=datasets,
                    fields=asso_fields,
                )
            )
        )
        plt.close()
        asso_score = rl.metrics.association_score(*datasets, asso_fields)
        fidelity_results_dict["asso_score"] = asso_score

    return fidelity_results_dict


@attrs.define(kw_only=True)
class PrivacyResults:
    memorization_rate: float
    dcr: Optional[float] = None
    linkability: Optional[float] = None
    inference: Optional[float] = None

    def average_privacy_score(self) -> float:
        scores = [1 - self.memorization_rate]
        if self.dcr is not None:
            scores.append(self.dcr)
        if self.linkability is not None:
            scores.append(self.linkability)
        if self.inference is not None:
            scores.append(self.inference)
        return np.mean(scores)


def _is_timeseries(config: dict[str, Any], dataset: LocalDataset) -> bool:
    if (
        config.get("session_key_field")
        or "session_key" in dataset.table.column_names
        or config.get("model_name") == "RF-Time-Transformer"
    ):
        return True
    return False


async def privacy_evaluate(
    ori: LocalDataset,
    syn: LocalDataset,
    data_info_dict: dict,
    *,
    conn: Optional[rf.AbstractConnection] = None,
    worker_group: Optional[str] = None,
    control: Optional[LocalDataset] = None,
    link_config: Optional[privacy.LinkabilityConfig] = None,
    inf_config: Optional[privacy.InferenceConfig] = None,
) -> PrivacyResults:
    """
    Evaluate the privacy of the synthetic data.

    :param ori:
        The original dataset.
    :param syn:
        The synthetic dataset.
    :param data_info_dict:
        The data information dictionary.
    :param conn:
        The connection to the Rockfish API.
    :param worker_group:
        The worker group to use for Rockfish actions.
    :param control:
        The control dataset.
    :param link_config:
        The linkability configuration.  If not provided, a default
        configuration will be used.  The label in the configuration will be
        overriden by an automatically generated unique name.
    :param inf_config:
        The inference configuration.  If not provided, a default configuration
        will be used.  The label in the configuration will be overriden by an
        automatically generated unique name.

    :return:
        The privacy results.
    """
    # Select fields in the same order (skipping ignored fields) from all
    # datasets for evaluation.  For timeseries datasets, session_key_field or
    # "session_key" are ignored.
    if _is_timeseries(data_info_dict, syn):
        fields = data_info_dict.get("metadata") + data_info_dict.get("measurements")
    else:
        fields = data_info_dict.get("metadata")
    ori.table = ori.table.select(fields)
    syn.table = syn.table.select(fields)
    memorization_rate = rl.metrics.memorization_rate(ori, syn)
    privacy_results = PrivacyResults(memorization_rate=memorization_rate)
    if control is not None:
        control.table = control.table.select(fields)
        dcr = rl.metrics.distance_to_closest_record_score(
            train_dataset=ori, test_dataset=control, syn=syn, transform="sigmoid"
        )
        privacy_results.dcr = dcr
    if conn is not None:
        linkability = await _get_privacy_metric(
            ori,
            syn,
            conn,
            "linkability",
            worker_group=worker_group,
            control=control,
            config=link_config,
        )
        inference = await _get_privacy_metric(
            ori,
            syn,
            conn,
            "inference",
            worker_group=worker_group,
            control=control,
            config=inf_config,
        )
        privacy_results.linkability = linkability
        privacy_results.inference = inference
    return privacy_results


async def _get_privacy_metric(
    ori: LocalDataset,
    syn: LocalDataset,
    conn: rf.AbstractConnection,
    metric: Literal["linkability", "inference"],
    *,
    worker_group: Optional[str] = None,
    config: privacy.LinkabilityConfig | privacy.InferenceConfig | None = None,
    control: Optional[LocalDataset] = None,
) -> float:
    datasets = [ori, syn] if control is None else [ori, syn, control]
    split_label = get_split_label(datasets)
    evaluate_privacy = _privacy_action(
        config, metric, ori, syn, control=control, split_label=split_label
    )
    save = ra.DatasetSave(name="test")
    builder = rf.WorkflowBuilder()
    builder.worker_group(worker_group)
    syn_remote = await syn.to_remote(conn)
    dataset_name_to_id = {"syn": syn_remote.id}
    query = f"""
select *,'ori' as {split_label} from ori
union all
select *,'syn' as {split_label} from syn
"""
    if control is not None:
        query += f"""union all
select *,'control' as {split_label} from control
"""
        control_remote = await control.to_remote(conn)
        dataset_name_to_id["control"] = control_remote.id
    concat = ra.SQL(
        query=query, table_name="ori", dataset_name_to_id=dataset_name_to_id
    )
    builder.add_path(ori, concat, evaluate_privacy, save)
    workflow = await builder.start(conn)

    try:
        async with workflow.logs().closing() as logs:
            async for log in logs:
                print(log)

        await workflow.wait(raise_on_failure=True)
    except BaseException:
        await workflow.stop()
        raise

    table = await workflow.datasets().concat(conn)
    return table.to_pandas().iloc[0, 0]


def _default_linkability_config(
    ori: LocalDataset,
    syn: LocalDataset,
    control: Optional[LocalDataset] = None,
) -> privacy.LinkabilityConfig:
    if syn.table.num_columns < 2:
        raise ValueError("Data must have at least 2 columns")
    middle = _default_n_features(syn.table.num_columns)
    upper = middle + _default_n_more_features(syn.table.num_columns)
    return privacy.LinkabilityConfig(
        n_attacks=_default_n_attacks(ori, syn, control),
        aux_cols_a=syn.table.column_names[:middle],
        aux_cols_b=syn.table.column_names[middle:upper],
    )


def _default_inference_config(
    ori: LocalDataset,
    syn: LocalDataset,
    control: Optional[LocalDataset] = None,
) -> privacy.InferenceConfig:
    if syn.table.num_columns < 2:
        raise ValueError("Data must have at least 2 columns")
    middle = _default_n_features(syn.table.num_columns)
    return privacy.InferenceConfig(
        n_attacks=_default_n_attacks(ori, syn, control),
        aux_cols=syn.table.column_names[:middle],
        secret=syn.table.column_names[middle],
    )


def _default_n_attacks(
    ori: LocalDataset, syn: LocalDataset, control: Optional[LocalDataset] = None
) -> int:
    n_attacks = min(500, ori.table.num_rows, syn.table.num_rows)
    if control is not None:
        n_attacks = min(n_attacks, control.table.num_rows)
    return n_attacks


def _default_n_features(num_columns: int) -> int:
    return min(3, (num_columns + 1) // 2)


def _default_n_more_features(num_columns: int) -> int:
    return min(6, num_columns)


def _privacy_action(
    config: privacy.LinkabilityConfig | privacy.InferenceConfig | None,
    metric: Literal["linkability", "inference"],
    ori: LocalDataset,
    syn: LocalDataset,
    *,
    control: Optional[LocalDataset] = None,
    split_label: str = "split_label",
) -> privacy.EvaluateLinkability | privacy.EvaluateInference:
    if config is None:
        config = (
            _default_linkability_config(ori, syn, control)
            if metric == "linkability"
            else _default_inference_config(ori, syn, control)
        )
    else:
        if (
            metric == "linkability"
            and isinstance(config, privacy.InferenceConfig)
            or metric == "inference"
            and isinstance(config, privacy.LinkabilityConfig)
        ):
            raise ValueError("Invalid config")
    config.label = split_label
    return (
        privacy.EvaluateLinkability(config)
        if metric == "linkability"
        else privacy.EvaluateInference(config)
    )
