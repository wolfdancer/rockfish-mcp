from itertools import chain

from rockfish.dataset import LocalDataset

_BASE_SPLIT_LABEL_NAME = "split_label"


def _generate_unique_name(used: list[str]) -> str:
    name = _BASE_SPLIT_LABEL_NAME
    if name not in used:
        return name
    i = 0
    while f"{name}_{i}" in used:
        i += 1
    return f"{name}_{i}"


def _get_column_names(datasets: list[LocalDataset]) -> list[str]:
    col_names = [ds.table.column_names for ds in datasets]
    return list(set(chain(*col_names)))


def get_split_label(datasets: list[LocalDataset]) -> str:
    return _generate_unique_name(_get_column_names(datasets))
